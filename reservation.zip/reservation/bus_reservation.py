import os
import smtplib

from dotenv import load_dotenv
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText



# DATABASE


buses = [
    {
        "bus_id": 101,
        "bus_name": "Orange Travels",
        "source": "Hyderabad",
        "destination": "Bangalore",
        "date": "10-08-2026",
        "time": "09:00 PM",
        "total_seats": 40,
        "available_seats": 40,
        "fare": 650
    },
    {
        "bus_id": 102,
        "bus_name": "VRL Travels",
        "source": "Hyderabad",
        "destination": "Chennai",
        "date": "11-08-2026",
        "time": "08:30 PM",
        "total_seats": 40,
        "available_seats": 40,
        "fare": 750
    }
]

bookings = []



# SEARCH BUS


def search_buses():

    print("\n")
    print("SEARCH BUS")

    source = input("Enter source: ").strip()
    destination = input("Enter destination: ").strip()

    found = False

    for bus in buses:

        if (
            bus["source"].lower() == source.lower()
            and
            bus["destination"].lower() == destination.lower()
        ):

            print("\nBus ID       :", bus["bus_id"])
            print("Bus Name     :", bus["bus_name"])
            print("Source       :", bus["source"])
            print("Destination  :", bus["destination"])
            print("Date         :", bus["date"])
            print("Time         :", bus["time"])
            print("Available    :", bus["available_seats"])
            print("Fare         :", bus["fare"])

            print("-" * 50)

            found = True

    if not found:
        print("\nNo buses found.")

# FIND BUS


def find_bus(bus_id):

    for bus in buses:

        if bus["bus_id"] == bus_id:
            return bus

    return None



# EMAIL CONFIGURATION


load_dotenv()

SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

SENDER_EMAIL = os.getenv("SENDER_EMAIL")
SENDER_PASSKEY = os.getenv("SENDER_PASSKEY")



# BOOKING EMAIL


def send_booking_email(to_email, booking):

    if not SENDER_EMAIL or not SENDER_PASSKEY:

        print("\nEmail configuration is missing.")
        print("Please check your .env file.")

        return False

    subject = "Bus Ticket Booking Confirmation"

    body = f"""
Hello {booking['passenger_name']},

Your bus ticket has been successfully confirmed.

       BUS TICKET CONFIRMATION


Ticket ID        : {booking['ticket_id']}
Passenger Name   : {booking['passenger_name']}
Email            : {booking['email']}
Phone Number     : {booking['phone']}
Gender           : {booking['gender']}
Age              : {booking['age']}

BUS DETAILS


Bus Name         : {booking['bus_name']}
Source           : {booking['source']}
Destination      : {booking['destination']}
Date             : {booking['date']}
Time             : {booking['time']}
Seat Number      : {booking['seat_no']}

Fare             : Rs.{booking['fare']}
Status           : {booking['status']}


Thank you for booking with us.

Have a safe journey!

Bus Reservation System
"""

    try:

        message = MIMEMultipart()

        message["From"] = SENDER_EMAIL
        message["To"] = to_email
        message["Subject"] = subject

        message.attach(
            MIMEText(body, "plain")
        )

        print("\nConnecting to Gmail SMTP server...")

        with smtplib.SMTP(
            SMTP_SERVER,
            SMTP_PORT
        ) as server:

            server.starttls()

            print("Logging into Gmail...")

            server.login(
                SENDER_EMAIL,
                SENDER_PASSKEY
            )

            print("Login successful.")

            server.sendmail(
                SENDER_EMAIL,
                to_email,
                message.as_string()
            )

        print("Email sent successfully!")
        print("Confirmation sent to:", to_email)

        return True

    except smtplib.SMTPAuthenticationError:

        print("\nEmail authentication failed.")
        print("Check your Gmail App Password.")

        return False

    except Exception as error:

        print("\nEmail sending failed.")
        print("Error:", error)

        return False


# CANCELLATION EMAIL


def send_cancellation_email(to_email, booking):

    if not SENDER_EMAIL or not SENDER_PASSKEY:

        print("\nEmail configuration is missing.")

        return False

    subject = "Bus Ticket Cancellation Confirmation"

    body = f"""
Hello {booking['passenger_name']},

Your bus ticket has been cancelled successfully.


       BUS TICKET CANCELLATION


Ticket ID        : {booking['ticket_id']}
Passenger Name   : {booking['passenger_name']}
Email            : {booking['email']}
Phone Number     : {booking['phone']}

BUS DETAILS


Bus Name         : {booking['bus_name']}
Source           : {booking['source']}
Destination      : {booking['destination']}
Date             : {booking['date']}
Time             : {booking['time']}
Seat Number      : {booking['seat_no']}

Fare             : Rs.{booking['fare']}
Status           : {booking['status']}


Your ticket has been cancelled successfully.

Thank you for using our Bus Reservation System.
"""

    try:

        message = MIMEMultipart()

        message["From"] = SENDER_EMAIL
        message["To"] = to_email
        message["Subject"] = subject

        message.attach(
            MIMEText(body, "plain")
        )

        with smtplib.SMTP(
            SMTP_SERVER,
            SMTP_PORT
        ) as server:

            server.starttls()

            server.login(
                SENDER_EMAIL,
                SENDER_PASSKEY
            )

            server.sendmail(
                SENDER_EMAIL,
                to_email,
                message.as_string()
            )

        print("Cancellation email sent successfully!")

        return True

    except smtplib.SMTPAuthenticationError:

        print("\nEmail authentication failed.")
        print("Check your Gmail App Password.")

        return False

    except Exception as error:

        print("\nEmail sending failed.")
        print("Error:", error)

        return False



# BOOK TICKET


def book_ticket():

    print("\n")
    print("BOOK TICKET")

    try:
        bus_id = int(input("Enter Bus ID: "))

    except ValueError:
        print("Please enter a valid Bus ID.")
        return

    bus = find_bus(bus_id)

    if bus is None:

        print("Bus not found.")
        return

    if bus["available_seats"] == 0:

        print("No seats available.")
        return

    print("\nBus Name    :", bus["bus_name"])
    print("Source      :", bus["source"])
    print("Destination :", bus["destination"])
    print("Date        :", bus["date"])
    print("Time        :", bus["time"])
    print("Fare        :", bus["fare"])
    print("Available   :", bus["available_seats"])

    name = input(
        "Enter passenger name: "
    ).strip()

    phone = input(
        "Enter mobile number: "
    ).strip()

    email = input(
        "Enter email address: "
    ).strip()

    gender = input(
        "Enter gender (Male/Female/Other): "
    ).strip()

    try:

        age = int(
            input("Enter passenger age: ")
        )

        seat_no = int(
            input("Enter seat number: ")
        )

    except ValueError:

        print("Please enter valid numbers.")
        return

    if seat_no < 1 or seat_no > bus["total_seats"]:

        print("Invalid seat number.")
        return

    # Check whether seat is already booked

    for booking in bookings:

        if (
            booking["bus_id"] == bus_id
            and
            booking["seat_no"] == seat_no
            and
            booking["status"] == "Confirmed"
        ):

            print("Seat already booked.")
            return

    ticket_id = 101 + len(bookings)

    booking = {

        "ticket_id": ticket_id,

        "bus_id": bus_id,

        "passenger_name": name,

        "phone": phone,

        "email": email,

        "gender": gender,

        "age": age,

        "seat_no": seat_no,

        "bus_name": bus["bus_name"],

        "source": bus["source"],

        "destination": bus["destination"],

        "date": bus["date"],

        "time": bus["time"],

        "fare": bus["fare"],

        "status": "Confirmed"
    }

    bookings.append(booking)

    bus["available_seats"] -= 1

    # Send confirmation email

    send_booking_email(
        email,
        booking
    )

    print("\n")
    print("TICKET BOOKED")

    print("Ticket ID      :", ticket_id)
    print("Passenger Name :", name)
    print("Phone          :", phone)
    print("Email          :", email)
    print("Gender         :", gender)
    print("Age            :", age)
    print("Bus Name       :", bus["bus_name"])
    print("Source         :", bus["source"])
    print("Destination    :", bus["destination"])
    print("Date           :", bus["date"])
    print("Time           :", bus["time"])
    print("Seat Number    :", seat_no)
    print("Fare           :", bus["fare"])
    print("Status         : Confirmed")



# CANCEL TICKET


def cancel_ticket():

    print("\n")
    print("CANCEL TICKET")

    if len(bookings) == 0:

        print("No bookings available.")
        return

    try:

        ticket_id = int(
            input("Enter Ticket ID: ")
        )

    except ValueError:

        print("Please enter a valid Ticket ID.")
        return

    for booking in bookings:

        if booking["ticket_id"] == ticket_id:

            if booking["status"] == "Cancelled":

                print("Ticket is already cancelled.")
                return

            booking["status"] = "Cancelled"

            bus = find_bus(
                booking["bus_id"]
            )

            if bus:

                bus["available_seats"] += 1

            # Send cancellation email

            send_cancellation_email(
                booking["email"],
                booking
            )

            print("\nTicket cancelled successfully.")
            print("Ticket ID :", ticket_id)
            print("Status    : Cancelled")

            return

    print("\nTicket not found.")



# TICKET HISTORY


def ticket_history():

    print("\n")
    print("TICKET HISTORY")

    if len(bookings) == 0:

        print("No bookings found.")
        return

    for booking in bookings:

        bus = find_bus(
            booking["bus_id"]
        )

        print("\nTicket ID      :", booking["ticket_id"])
        print("Passenger Name :", booking["passenger_name"])
        print("Phone          :", booking["phone"])
        print("Email          :", booking["email"])
        print("Gender         :", booking["gender"])
        print("Age            :", booking["age"])
        print("Bus Name       :", bus["bus_name"])
        print("Source         :", bus["source"])
        print("Destination    :", bus["destination"])
        print("Date           :", bus["date"])
        print("Time           :", bus["time"])
        print("Seat Number    :", booking["seat_no"])
        print("Fare           :", bus["fare"])
        print("Status         :", booking["status"])



# MAIN MENU


def main():

    while True:

        print("\n")
        print("BUS RESERVATION SYSTEM")

        print("1. Search Bus")
        print("2. Book Ticket")
        print("3. Cancel Ticket")
        print("4. Ticket History")
        print("5. Exit")

        choice = input(
            "Enter your choice: "
        ).strip()

        if choice == "1":

            search_buses()

        elif choice == "2":

            book_ticket()

        elif choice == "3":

            cancel_ticket()

        elif choice == "4":

            ticket_history()

        elif choice == "5":

            print(
                "\nThank you for using "
                "Bus Reservation System."
            )

            break

        else:

            print(
                "\nInvalid choice. "
                "Please try again."
            )


if __name__ == "__main__":
    main()